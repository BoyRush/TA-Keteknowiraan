import os
import chromadb
from chromadb.config import Settings
from chromadb.utils import embedding_functions


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CHROMA_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "chroma_db"))

embedding_function = embedding_functions.SentenceTransformerEmbeddingFunction(
    model_name="all-MiniLM-L6-v2"
)


chroma_client = chromadb.PersistentClient(
    path=CHROMA_DIR
)

collection = chroma_client.get_or_create_collection(
    name="herbal_collection",
    embedding_function=embedding_function
)

def add_herbal(doc_id, text, metadata=None):
    collection.add(
        ids=[doc_id],
        documents=[text],
        metadatas=[metadata or {}]
    )

def search_herbal(query, n_results=3):
    return collection.query(
        query_texts=[query],
        n_results=n_results
    )

def count_herbal():
    return collection.count()
