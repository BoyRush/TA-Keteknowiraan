from flask import Flask, request, jsonify
from flask_cors import CORS 
from blockchain.health_record_service import (
    store_medical_record,
    grant_access,
    revoke_access,
    get_medical_records_as_doctor,
    get_patient_medical_conditions
)
from ipfs.ipfs_service import upload_json_to_ipfs
from chroma.herbal_store import add_herbal, search_herbal
from rules.medical_rules import filter_herbs_by_medical_condition
from services.herbal_builder import build_herbs
from services.llm_schema_builder import build_llm_input
from services.llm_generator import generate_herbal_recommendation
from services.herbal_retriever import retrieve_relevant_herbs
from blockchain.contract import web3, contract





app = Flask(__name__)
CORS(
    app,
    supports_credentials=True,
    origins=["http://localhost:5173"]
)

@app.route("/", methods=["GET"])
def index():
    return {"status": "Backend running"}, 200

# =========================
# HERBAL (SEMANTIC SEARCH)
# =========================
@app.route("/herbal/search", methods=["GET"])
def search_herbal_api():
    query = request.args.get("q")
    medical_raw = request.args.get("medical", "")

    if not query:
        return jsonify({"error": "query kosong"}), 400

    medical_conditions = [
        m.strip().lower()
        for m in medical_raw.split(",")
        if m
    ]

    result = search_herbal(query)

    herbs = []
    if result["documents"] and result["documents"][0]:
        for i in range(len(result["documents"][0])):
            herbs.append({
                "id": result["ids"][0][i],
                "name": result["metadatas"][0][i].get("name"),
                "indikasi": result["metadatas"][0][i].get("indikasi"),
                "kontraindikasi": result["metadatas"][0][i].get("kontraindikasi"),
                "deskripsi": result["documents"][0][i],
                "score": result["distances"][0][i]
            })

    if medical_conditions:
        herbs = filter_herbs_by_medical_condition(herbs, medical_conditions)

    return jsonify({
        "query": query,
        "medical_conditions": medical_conditions,
        "results": herbs
    })


@app.route("/herbal/recommendation-input", methods=["GET"])
def recommendation_input():
    query = request.args.get("q")
    medical = request.args.get("medical", "")

    medical_conditions = [m.strip().lower() for m in medical.split(",") if m]

    # 🧠 1. RAG: ambil herbal relevan dari Chroma
    herbs_from_rag = retrieve_relevant_herbs(query)

    # 🩺 2. RULE-BASED FILTER (kondisi medis)
    safe_herbs = filter_herbs_by_medical_condition(
        herbs_from_rag,
        medical_conditions
    )

    # 📦 3. BANGUN INPUT LLM
    llm_input = build_llm_input(
        query,
        medical_conditions,
        safe_herbs
    )

    # 🤖 4. LLM (HANYA reasoning & formatting)
    llm_output = generate_herbal_recommendation(llm_input)

    return jsonify(llm_output)




# =========================
# IPFS  
# =========================
@app.route("/ipfs/upload", methods=["POST"])
def upload_ipfs():
    data = request.json
    cid = upload_json_to_ipfs(data)
    return jsonify({
        "cid": cid
    })


@app.route("/medical/upload-and-store", methods=["POST"])
def upload_and_store_medical():
    data = request.json

    # 1. ambil private key pasien
    patient_private_key = data["patient_private_key"]

    # 2. ambil data medis (selain private key)
    medical_data = data["medical_data"]

    # 3. upload ke IPFS
    cid = upload_json_to_ipfs(medical_data)

    # 4. simpan CID ke blockchain
    tx_hash = store_medical_record(
        patient_private_key,
        cid
    )

    return jsonify({
        "cid": cid,
        "tx_hash": tx_hash
    })


# =========================
# PASIEN
# =========================

@app.route("/patient/grant-access", methods=["POST"])
def grant_access_api():
    data = request.json
    tx_hash = grant_access(
        data["patient_private_key"],
        data["doctor_address"]
    )
    return jsonify({"tx_hash": tx_hash})


@app.route("/patient/revoke-access", methods=["POST"])
def revoke_access_api():
    data = request.json
    tx_hash = revoke_access(
        data["patient_private_key"],
        data["doctor_address"]
    )
    return jsonify({"tx_hash": tx_hash})

@app.route("/patient/request-recommendation", methods=["POST"])
def patient_request_recommendation():
    data = request.json

    patient_address = data["patient_address"]
    keluhan = data["keluhan"]

    # 1️⃣ AMBIL DARI BC
    medical_conditions = get_patient_medical_conditions(
        patient_address,
        data["doctor_private_key"]
    )

    print("MEDICAL FROM BC:", medical_conditions)

    # 2️⃣ RAG
    herbs_from_rag = retrieve_relevant_herbs(keluhan)

    # 3️⃣ RULE BASED
    safe_herbs = filter_herbs_by_medical_condition(
        herbs_from_rag,
        medical_conditions
    )

    # 4️⃣ LLM
    llm_input = build_llm_input(
        keluhan,
        medical_conditions,
        safe_herbs
    )

    llm_output = generate_herbal_recommendation(llm_input)

    return jsonify({
        "patient_context": {
            "keluhan": keluhan,
            "kondisi_medis": medical_conditions
        },
        "rekomendasi": llm_output
    })


@app.route("/medical/store", methods=["POST"])
def store_medical():
    data = request.json
    tx_hash = store_medical_record(
        data["patient_private_key"],
        data["cid"]
    )
    return jsonify({"tx_hash": tx_hash})


@app.route("/medical/grant", methods=["POST"])
def grant():
    data = request.json
    tx_hash = grant_access(
        data["patient_private_key"],
        data["doctor_address"]
    )
    return jsonify({"tx_hash": tx_hash})


@app.route("/medical/revoke", methods=["POST"])
def revoke():
    data = request.json
    tx_hash = revoke_access(
        data["patient_private_key"],
        data["doctor_address"]
    )
    return jsonify({"tx_hash": tx_hash})


# =========================
# DOKTER
# =========================

@app.route("/doctor/medical-records", methods=["GET"])
def get_records():
    patient = request.args.get("patient")
    doctor = request.args.get("doctor")
    records = get_medical_records_as_doctor(patient, doctor)
    return jsonify(records)


if __name__ == "__main__":
    app.run(debug=True)



